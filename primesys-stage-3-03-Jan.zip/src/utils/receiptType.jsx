export const receiptType = [
  { value: "cash", label: "Cash" },
  { value: "nets", label: "Nets" },
  { value: "paynow", label: "Pay Now" },
  { value: "banktransfer", label: "Bank Transfer" },
  { value: "creditcard", label: "Credit Card" },
  { value: "cheque", label: "Cheque" },
];
