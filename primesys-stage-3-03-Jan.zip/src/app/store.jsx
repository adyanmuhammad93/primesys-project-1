import { configureStore } from "@reduxjs/toolkit";
import studentSlice from "./studentSlice";
import contactSlice from "./contactSlice";

export const appStore = configureStore({
  reducer: {
    contact: contactSlice,
    student: studentSlice,
  },
});
