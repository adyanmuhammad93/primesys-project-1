import db from "../db.js";

const getContacts = async () => {
  const [rows, fields] = await db.execute("SELECT * FROM contacts");
  return rows;
};

const getContactById = async (id) => {
  const [rows, fields] = await db.execute(
    "SELECT * FROM contacts WHERE contactid = ?",
    [id]
  );
  return rows;
};

const addStudent = async (student) => {
  const fields = [
    "name",
    "sex",
    "idno",
    "dob",
    "race",
    "placeofbirth",
    "nationality",
    "identificationtype",
    "address1",
    "address2",
    "address3",
    "addresspostalcode",
    "addresscountry",
    "phonenumber",
    "hpnumber",
    "emailaddress",
    "enteredby",
    "entereddate",
    "active",
  ];
  const values = fields.map((field) => student[field]);
  const placeholders = fields.map(() => "?").join(", ");
  const sql = `INSERT INTO contacts (${fields.join(
    ", "
  )}) VALUES (${placeholders})`;
  const [result] = await db.query(sql, values);
  if (result) {
    const [rows] = await db.query(
      "SELECT * FROM contacts WHERE contactid = ?",
      [result.insertId]
    );
    return {
      message: "Student added successfully!",
      contactid: result.insertId,
      data: rows[0], // The newly inserted data
    };
  } else {
    throw new Error("Failed to add student!");
  }
};

const updateStudent = async (student) => {
  console.log(student);
  const fields = [
    "name",
    "sex",
    "idno",
    "dob",
    "race",
    "placeofbirth",
    "nationality",
    "identificationtype",
    "address1",
    "address2",
    "address3",
    "addresspostalcode",
    "addresscountry",
    "phonenumber",
    "hpnumber",
    "emailaddress",
    "enteredby",
    "entereddate",
  ];
  const values = fields.map((field) => student[field]);
  const sql =
    "UPDATE contacts SET name = ?, sex = ?, idno = ?, dob = ?, race = ?, placeofbirth = ?, nationality = ?, identificationtype = ?, address1 = ?, address2 = ?, address3 = ?, addresspostalcode = ?, addresscountry = ?, phonenumber = ?, hpnumber = ?, emailaddress = ?, enteredby = ?, entereddate = ? WHERE contactid = ?";
  const [result] = await db.query(sql, [...values, student.contactid]);
  if (result) {
    const [rows] = await db.query(
      "SELECT * FROM contacts WHERE contactid = ?",
      [student.contactid]
    );
    return {
      message: "Student updated successfully!",
      data: rows[0], // The updated data
    };
  } else {
    throw new Error("Failed to update student!");
  }
};

const addGuardian = async (guardian) => {
  const fields = [
    "name",
    "sex",
    "idno",
    "dob",
    "race",
    "placeofbirth",
    "nationality",
    "identificationtype",
    "address1",
    "address2",
    "address3",
    "addresspostalcode",
    "addresscountry",
    "phonenumber",
    "hpnumber",
    "emailaddress",
    "enteredby",
    "entereddate",
    "active",
    "highestqual",
    "maritialstatus",
    "householdincome",
    "residencetype",
    "emergencycontact",
  ];
  const values = fields.map((field) => guardian[field]);
  const placeholders = fields.map(() => "?").join(", ");
  const sql = `INSERT INTO contacts (${fields.join(
    ", "
  )}) VALUES (${placeholders})`;
  const [result] = await db.query(sql, values);
  if (result) {
    return {
      message: "Guardian added successfully!",
      contactid: result.insertId,
    };
  } else {
    throw new Error("Failed to add guardian!");
  }
};

const addRelationship = async (relationship) => {
  const fields = ["contactid", "relatedtoid", "realatedtypeid"];
  const values = fields.map((field) => relationship[field]);
  console.log(placeholders);
  const placeholders = fields.map(() => "?").join(", ");
  const sql = `INSERT INTO contactrelate (${fields.join(
    ", "
  )}) VALUES (${placeholders})`;
  const [result] = await db.query(sql, values);
  if (result) {
    return {
      message: "Relationship added successfully!",
      contactid: result.insertId,
    };
  } else {
    throw new Error("Failed to add relationship!");
  }
};

const getContactRelate = async (id) => {
  const sql = "SELECT * FROM contactrelate WHERE contactid = ?";
  const [rows, fields] = await db.execute(sql, [id]);
  return rows;
};

const updateOtherInfo = async (id, other) => {
  const fields = [
    "langusedathome",
    "nameofschattended",
    "dateofschattended",
    "illness",
    "docobservation",
    "applotherinst",
    "emergencycontacname",
    "emergencycontactoffice",
    "emergencycontacthp",
    "emergencycontacthome",
    "emergencyrelation",
    "notes",
  ];
  const values = fields.map((field) => other[field]);
  const placeholders = fields.map(() => "?").join(", ");
  const sql = `UPDATE contacts SET ${fields.join(
    " = ?, "
  )} = ? WHERE contactid = ?`;
  const [result] = await db.query(sql, [...values, id]);
  if (result) {
    return {
      message: "Other Information updated successfully!",
      contactid: id,
    };
  } else {
    throw new Error("Failed to update Other Information!");
  }
};

export {
  getContacts,
  getContactById,
  addStudent,
  updateStudent,
  addGuardian,
  addRelationship,
  getContactRelate,
  updateOtherInfo,
};
