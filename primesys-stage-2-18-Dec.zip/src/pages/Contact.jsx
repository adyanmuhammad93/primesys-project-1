import { useEffect, useMemo, useState } from "react";
import useContact from "../hooks/useContact";
import Table from "../components/Table";
import { FiEdit, FiTrash } from "react-icons/fi";
import Modal from "../components/Modal";
import Stepper from "../components/Stepper";
import StepperEdit from "../components/StepperEdit";

const Contact = () => {
  // HOOK
  const { contact, loading, error, updateStudent, updateOtherInfo } =
    useContact();

  // COLUMNS
  const columns = useMemo(
    () => [
      {
        Header: "No",
        Cell: ({ row }) => row.index + 1,
      },
      {
        Header: "Name",
        accessor: "name",
      },
      {
        Header: "Phone Number",
        accessor: "phonenumber",
      },
      {
        Header: "Date of Birth",
        accessor: "dob",
      },
      {
        Header: "Nationality",
        accessor: "nationality",
      },
      {
        Header: "Actions",
        Cell: ({ row }) => (
          <div className="flex gap-4">
            <button
              className="btn btn-xs btn-square"
              onClick={() => handleEdit(row.original)}
            >
              <FiEdit />
            </button>
            <button
              className="btn btn-xs btn-square"
              onClick={() => handleDelete(row.original.contactid)}
            >
              <FiTrash />
            </button>
          </div>
        ),
      },
    ],
    []
  );

  // ACTIONS
  const [selectedRow, setSelectedRow] = useState(null);
  const handleEdit = (row) => {
    setSelectedRow(row);
    console.log(row);
    document.getElementById("editContact").showModal();
  };

  const handleDelete = () => {
    console.log("Test");
  };
  return (
    <>
      <div className="mx-auto py-4 w-[90%] max-w-[1200px]">
        <Table
          loading={loading}
          error={error}
          // 1
          title="Contact List"
          shortDescription="List of Contact Added"
          // 2
          // 3
          showArchive={false}
          // 4
          handleAddButton={() =>
            document.getElementById("addContact").showModal()
          }
          addButtonLabel="Add Contact"
          // 5
          columns={columns}
          data={contact}
          // 6
        />
        <Modal id="addContact">
          <Stepper />
        </Modal>
        <Modal id="editContact">
          <StepperEdit
            selectedRow={selectedRow}
            updateStudent={updateStudent}
            updateOther={updateOtherInfo}
          />
        </Modal>
      </div>
    </>
  );
};

export default Contact;
