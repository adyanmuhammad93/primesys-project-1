import { useState } from "react";
import Step1Edit from "./Step1Edit";
import Step2Edit from "./Step2Edit";
import Step3Edit from "./Step3Edit";

const StepperEdit = ({ selectedRow, updateStudent, updateOther }) => {
  const [step, setStep] = useState(1);
  const nextStep = () => {
    setStep(step + 1);
  };

  const prevStep = () => {
    setStep(step - 1);
  };
  return (
    <>
      <div className="flex flex-col gap-8 p-4">
        {/* <h2>This is Stepper</h2> */}
        <div className="grid grid-cols-3 gap-4">
          <div
            className={`px-4 py-2 ${
              step === 1 ? "bg-slate-500" : "bg-slate-300"
            } text-white rounded-xl`}
          >
            Step 1
          </div>
          <div
            className={`px-4 py-2 ${
              step === 2 ? "bg-slate-500" : "bg-slate-300"
            } text-white rounded-xl`}
          >
            Step 2
          </div>
          <div
            className={`px-4 py-2 ${
              step === 3 ? "bg-slate-500" : "bg-slate-300"
            } text-white rounded-xl`}
          >
            Step 3
          </div>
        </div>
        {step === 1 && (
          <Step1Edit selectedRow={selectedRow} action={updateStudent} />
        )}
        {step === 2 && <Step2Edit selectedRow={selectedRow} />}
        {step === 3 && (
          <Step3Edit selectedRow={selectedRow} action={updateOther} />
        )}
        <div className="flex justify-between">
          <button
            className="btn btn-sm"
            onClick={() => prevStep()}
            disabled={step === 1 && true}
          >
            Prev
          </button>
          <button
            className="btn btn-sm"
            onClick={() => nextStep()}
            disabled={step === 3 && true}
          >
            Next
          </button>
        </div>
      </div>
    </>
  );
};

export default StepperEdit;
