import React from "react";

const Dashboard = () => {
  return (
    <>
      <div className="p-4">Hello, welcome back!</div>
    </>
  );
};

export default Dashboard;
