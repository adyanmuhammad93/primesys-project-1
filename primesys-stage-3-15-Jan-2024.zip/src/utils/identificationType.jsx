export const identificationType = [
  { value: "Citizen", label: "Singapore Citizen" },
  { value: "StdPass", label: "Student Pass" },
  { value: "SGPPR", label: "Singapore PR" },
  { value: "DpdPass", label: "Dependent Pass" },
  { value: "VisitPass", label: "Visit Pass" },
];
