import {
  Route,
  createBrowserRouter,
  createRoutesFromElements,
} from "react-router-dom";
import Home from "../pages/Home";
import ReceiptList from "../pages/ReceiptList";
import ReceiptNew from "../pages/ReceiptNew";
import Contact from "../pages/Contact";
import MainLayout from "../components/layout/MainLayout";
import DashboardLayout from "../components/layout/DashboardLayout";
import SignIn from "../pages/SignIn";
import InvoiceList from "../pages/invoice/list";
import InvoiceNew from "../pages/invoice/new";
import InvoiceEdit from "../pages/invoice/edit";

export const appRoute = createBrowserRouter(
  createRoutesFromElements(
    <>
      <Route element={<MainLayout />}>
        <Route path="/" element={<SignIn />} />
        <Route element={<DashboardLayout />}>
          <Route path="/dashboard" element={<>Hello!</>} />
          <Route path="/receipt" element={<ReceiptList />} />
          <Route path="/receipt/new" element={<ReceiptNew />} />
          <Route path="/contact" element={<Contact />} />
          <Route path="/invoice" element={<InvoiceList />} />
          <Route path="/invoice/new" element={<InvoiceNew />} />
          <Route path="/invoice/edit/:id" element={<InvoiceEdit />} />
        </Route>
      </Route>
    </>
  )
);
