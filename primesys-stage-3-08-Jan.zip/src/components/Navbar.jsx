import React from "react";
import { Link } from "react-router-dom";

const Navbar = () => {
  return (
    <>
      <div className="navbar bg-slate-200">
        <div className="mx-auto w-[90%] max-w-7xl flex">
          <div className="flex-1">
            <Link to="/" className="btn btn-ghost text-xl">
              PrimeSys
            </Link>
          </div>
          <div className="flex-none">
            <ul className="menu menu-horizontal px-1">
              <div className="dropdown dropdown-hover dropdown-end">
                <div tabIndex={0} role="button" className="btn btn-sm m-1">
                  Activities
                </div>
                <ul className="dropdown-content z-[1] menu menu-sm p-2 shadow bg-base-100 rounded-box w-52">
                  <li>
                    <a>Billing</a>
                  </li>
                  <li>
                    <Link to="/receipt">Receipt</Link>
                  </li>
                  <li>
                    <a>GIRO</a>
                  </li>
                  <li>
                    <a>Xero Transfer</a>
                  </li>
                </ul>
              </div>
              <div className="dropdown dropdown-hover dropdown-end">
                <div tabIndex={0} role="button" className="btn btn-sm m-1">
                  List
                </div>
                <ul className="dropdown-content z-[1] menu menu-sm p-2 shadow bg-base-100 rounded-box w-52">
                  <li>
                    <Link to="/contact">Contacts</Link>
                  </li>
                  <li>
                    <a>Courses</a>
                  </li>
                </ul>
              </div>
              <div className="dropdown dropdown-hover dropdown-end">
                <div tabIndex={0} role="button" className="btn btn-sm m-1">
                  Setup
                </div>
                <ul className="dropdown-content z-[1] menu menu-sm p-2 shadow bg-base-100 rounded-box w-52">
                  <li>
                    <a>Item 1</a>
                  </li>
                  <li>
                    <a>Item 2</a>
                  </li>
                </ul>
              </div>
            </ul>
          </div>
        </div>
      </div>
    </>
  );
};

export default Navbar;
