export const gstCodes = [
  { value: 0.08, label: "Standard-Rated Purchase" },
  { value: 0, label: "No Tax" },
];
