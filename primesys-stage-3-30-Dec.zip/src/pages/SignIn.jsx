import React from "react";
import { Link } from "react-router-dom";
import TextInputLookUp from "../components/TextInputLookUp";
import TextInput from "../components/TextInput";

const SignIn = () => {
  return (
    <>
      <div className="grow flex flex-col items-center justify-center gap-8">
        <h1 className="text-3xl font-bold uppercase">PrimeSys</h1>
        <p className="text-2xl font-medium">Log in into your account</p>
        <div className="w-full max-w-[400px]">
          <div className="flex flex-col gap-4">
            <TextInputLookUp
              gridWidth="col-span-4"
              type="email"
              placeholder="Email Address"
              inputClass={`bg-slate-200`}
            />
            <TextInput
              gridWidth="col-span-4"
              type="password"
              placeholder="Password"
              inputClass={`bg-slate-200`}
            />
            <Link to="/dashboard" className="btn btn-primary col-span-4">
              Sign In
            </Link>
          </div>
        </div>
        <a href="" className="link">
          Forgot your password?
        </a>
        <p>
          Don't have an account?{" "}
          <a href="" className="link">
            Sign up
          </a>
        </p>
      </div>
    </>
  );
};

export default SignIn;
