import { Router } from "express";
import {
  getInvoices,
  getInvoicesById,
  saveInvoiceDetails,
  saveInvoiceHeader,
} from "../services/invoiceServices.js";

const invoiceRoutes = Router(); // Instantiate Router

// READ
invoiceRoutes.get("/invoice", async (req, res) => {
  const data = await getInvoices();
  res.json(data);
  console.log(data);
});

// READ ONE
invoiceRoutes.get("/invoice/:id", async (req, res) => {
  const data = await getInvoicesById(req.params.id);
  console.log(req.params.id);
  res.json(data);
});

// CREATE
invoiceRoutes.post("/invoice/save", async (req, res) => {
  const { invoiceHeaderData, invoiceDetailsData } = req.body;
  const headerValues = [
    invoiceHeaderData.to,
    invoiceHeaderData.issueDate,
    invoiceHeaderData.invoiceNumber,
    invoiceHeaderData.reference | null,
  ];

  try {
    const headerId = await saveInvoiceHeader(headerValues);
    await saveInvoiceDetails(headerId, invoiceDetailsData);
    res.status(200).json({
      message: "Invoice Header and Details saved succcessfully!",
      salesinvid: headerId,
    });
  } catch (error) {
    console.error("Error saving Invoice!", error);
    res.status(500).json({ error: "Error saving Invoice" });
  }
});

export default invoiceRoutes; // Export the router
