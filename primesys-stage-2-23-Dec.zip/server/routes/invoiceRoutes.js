import { Router } from "express";
import { getInvoices, getInvoicesById } from "../services/invoiceServices.js";

const invoiceRoutes = Router(); // Instantiate Router

// READ
invoiceRoutes.get("/invoice", async (req, res) => {
  const data = await getInvoices();
  res.json(data);
});

// READ ONE
invoiceRoutes.get("/invoice/:id", async (req, res) => {
  const data = await getInvoicesById(req.params.id);
  console.log(req.params.id);
  res.json(data);
});

export default invoiceRoutes; // Export the router
