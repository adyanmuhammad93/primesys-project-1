import db from "../db.js";

const getInvoices = async () => {
  let sql = `
    SELECT
      C.Name,
      H.salesinvid,
      H.salesinvdate,
      H.salesinvref,
      H.salesamtincgst,
      IFNULL(H.salesamtincgst - Paid.sumpaid, 0) AS amtos,
      H.salesamtincgst AS amtdue,
      IFNULL(Paid.sumpaid, 0) AS amtpaid,
      H.ContactId
    FROM
      salesinv H
    LEFT JOIN
      contacts C ON C.ContactId = H.ContactId
    LEFT JOIN (
      SELECT
        entry,
        SUM(amountapplied) AS sumpaid
      FROM
        rcarapbal AS R
      WHERE
        R.active = 1
      GROUP BY
        entry
    ) AS Paid ON Paid.entry = H.salesinvid
    WHERE
      H.active = 1
      AND IFNULL(H.salesamtincgst - Paid.sumpaid, 0) = 0;
  `;
  const [rows, fields] = await db.execute(sql);
  return rows;
};

const getInvoicesById = async (id) => {
  let sql = `
    SELECT
      C.Name,
      H.salesinvid,
      H.salesinvdate,
      H.salesinvref,
      IFNULL(H.salesamtincgst - Paid.sumpaid, 0) AS amtos,
      H.salesamtincgst AS amtdue,
      IFNULL(Paid.sumpaid, 0) AS amtpaid,
      H.ContactId
    FROM
      salesinv H
    LEFT JOIN
      contacts C ON C.ContactId = H.ContactId
    LEFT JOIN (
      SELECT
        entry,
        SUM(amountapplied) AS sumpaid
      FROM
        rcarapbal AS R
      WHERE
        R.active = 1
      GROUP BY
        entry
    ) AS Paid ON Paid.entry = H.salesinvid
    WHERE
      H.contactId = ?
      AND H.active = 1
      AND IFNULL(H.salesamtincgst - Paid.sumpaid, 0) = 0;
  `;
  const [rows, fields] = await db.execute(sql, [id]);
  return rows;
};

export { getInvoices, getInvoicesById };
