import { useEffect, useState } from "react";
import axios from "axios";

const useInvoice = () => {
  const [invoice, setInvoice] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  useEffect(() => {
    const fetchInvoice = async () => {
      try {
        const response = await axios.get(
          `${import.meta.env.VITE_API_URL}/invoice`
        );
        setInvoice(response.data);
        setTimeout(() => setLoading(false), 1000); // Delay setting loading to false by 1 second
      } catch (error) {
        setError(error);
        setLoading(false);
      }
    };

    fetchInvoice();
  }, []);

  const fetchInvoiceById = async (id) => {
    try {
      const response = await axios.get(
        `${import.meta.env.VITE_API_URL}/invoice/${id}`
      );
      return response;
    } catch (error) {
      setError(error);
      setLoading(false);
    }
  };

  return {
    invoice,
    loading,
    error,
    fetchInvoiceById,
  };
};

export default useInvoice;
